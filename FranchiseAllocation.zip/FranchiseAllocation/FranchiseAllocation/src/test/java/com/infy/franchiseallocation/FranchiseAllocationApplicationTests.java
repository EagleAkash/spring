package com.infy.franchiseallocation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FranchiseAllocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
