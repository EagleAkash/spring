package com.infy.franchiseallocation.repository;

public interface FranchiseRepository {

}
