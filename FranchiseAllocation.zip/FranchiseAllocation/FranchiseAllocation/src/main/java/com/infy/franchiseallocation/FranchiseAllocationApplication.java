package com.infy.franchiseallocation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FranchiseAllocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FranchiseAllocationApplication.class, args);
	}

}
