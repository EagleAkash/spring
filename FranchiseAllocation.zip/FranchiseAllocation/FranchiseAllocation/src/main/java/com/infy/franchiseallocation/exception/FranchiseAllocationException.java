package com.infy.franchiseallocation.exception;

public class FranchiseAllocationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FranchiseAllocationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
