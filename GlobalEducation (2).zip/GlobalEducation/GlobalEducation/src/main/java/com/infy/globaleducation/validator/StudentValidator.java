package com.infy.globaleducation.validator;

import com.infy.globaleducation.dto.StudentDTO;
import com.infy.globaleducation.exception.GlobalEducationException;

public class StudentValidator {

	public StudentValidator() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static void validateStudent(StudentDTO studentDTO) throws GlobalEducationException
	{
		
	}
	public static Boolean isValidIntakeYear(String intakeYear) 
	{
		return null;
		
	}

}
