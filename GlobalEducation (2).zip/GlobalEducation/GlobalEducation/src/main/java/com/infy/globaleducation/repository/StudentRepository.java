package com.infy.globaleducation.repository;

public interface StudentRepository {

}
