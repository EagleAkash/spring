package com.infy.globaleducation.exception;

public class GlobalEducationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GlobalEducationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
