package com.infy.infytvseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyTvSeriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
