package com.infy.infytvseries.validator;

import java.time.LocalDate;

import com.infy.infytvseries.dto.UserDTO;
import com.infy.infytvseries.exception.SeriesBookingException;

public class UserValidator {
	
	public UserValidator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void validateUser(UserDTO userDTO) throws SeriesBookingException
	{
		
	}

	public static Boolean isValidRegDate(LocalDate regDate) {
		return null;
		
	
	}
}
