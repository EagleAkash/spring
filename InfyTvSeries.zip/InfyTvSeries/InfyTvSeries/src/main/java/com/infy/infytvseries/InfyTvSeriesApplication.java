package com.infy.infytvseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfyTvSeriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfyTvSeriesApplication.class, args);
	}

}
