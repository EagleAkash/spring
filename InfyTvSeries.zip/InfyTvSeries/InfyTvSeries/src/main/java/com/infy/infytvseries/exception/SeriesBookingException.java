package com.infy.infytvseries.exception;

public class SeriesBookingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SeriesBookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
