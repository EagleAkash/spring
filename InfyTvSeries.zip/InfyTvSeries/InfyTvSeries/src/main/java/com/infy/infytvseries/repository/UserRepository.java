package com.infy.infytvseries.repository;

public interface UserRepository {

}
