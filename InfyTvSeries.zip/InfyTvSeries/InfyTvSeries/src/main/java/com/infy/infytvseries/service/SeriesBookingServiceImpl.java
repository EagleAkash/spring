package com.infy.infytvseries.service;

import com.infy.infytvseries.dto.UserDTO;
import com.infy.infytvseries.exception.SeriesBookingException;
import com.infy.infytvseries.repository.UserRepository;

public class SeriesBookingServiceImpl implements SeriesBookingService{
	
	private UserRepository userRepository;

	@Override
	public UserDTO registerUser(UserDTO userDTO) throws SeriesBookingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDTO getDetailsByUserEmail(String email) throws SeriesBookingException {
		// TODO Auto-generated method stub
		return null;
	}

}
