package com.infy.rentacar.repository;

public interface RentalRepository {

}
