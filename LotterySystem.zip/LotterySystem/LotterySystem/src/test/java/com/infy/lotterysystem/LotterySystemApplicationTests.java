package com.infy.lotterysystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotterySystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
