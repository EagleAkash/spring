package com.infy.lotterysystem.exception;

public class LotteryBookingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LotteryBookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
