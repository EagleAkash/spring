package com.infy.lotterysystem.repository;

public interface ParticipantRepository {

}
