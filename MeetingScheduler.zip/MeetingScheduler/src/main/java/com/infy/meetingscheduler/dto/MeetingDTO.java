package com.infy.meetingscheduler.dto;

import java.time.LocalDate;

import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.infy.meetingscheduler.entity.Meeting;

public class MeetingDTO {
	
	private Integer meetingId;
	@NotNull(message = "{meeting.scheduler.absent}")
	@Pattern(regexp = "[A-Za-z]+(\\s[A-Za-z]+)*", message = "{meeting.scheduler.invalid}")
	private String schedulerName;
	@NotNull(message = "{meeting.name.absent}")
	private String teamName;
	@NotNull(message = "{meeting.purpose.absent}")
	private String purpose;
	@NotNull(message = "{meeting.date.absent}")
	@FutureOrPresent(message = "{meeting.date.invalid}")
	private LocalDate meetingDate;
	public Integer getMeetingId() {
		return meetingId;
	}
	public void setMeetingId(Integer meetingId) {
		this.meetingId = meetingId;
	}
	public String getSchedulerName() {
		return schedulerName;
	}
	public void setSchedulerName(String schedulerName) {
		this.schedulerName = schedulerName;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public LocalDate getMeetingDate() {
		return meetingDate;
	}
	public void setMeetingDate(LocalDate meetingDate) {
		this.meetingDate = meetingDate;
	}
	public  static MeetingDTO prepareDTO(Meeting meeting)
	{
		MeetingDTO meetingDTO=new MeetingDTO();
		meetingDTO.setMeetingId(meeting.getMeetingId());
		meetingDTO.setSchedulerName(meeting.getSchedulerName());
		meetingDTO.setTeamName(meeting.getTeamName());
		meetingDTO.setPurpose(meeting.getPurpose());
		meetingDTO.setMeetingDate(meeting.getMeetingDate());
		
		return meetingDTO;
		
	}
	public static Meeting prepareEntity(MeetingDTO meetingDTO)
	{
		Meeting meeting=new Meeting();
		meeting.setSchedulerName(meetingDTO.getSchedulerName());
		meeting.setTeamName(meetingDTO.getTeamName());
		meeting.setPurpose(meetingDTO.getPurpose());
		meeting.setMeetingDate(meetingDTO.getMeetingDate());
		
		return meeting;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
