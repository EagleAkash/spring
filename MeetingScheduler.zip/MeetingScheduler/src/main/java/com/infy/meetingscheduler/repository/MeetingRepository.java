package com.infy.meetingscheduler.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.infy.meetingscheduler.entity.Meeting;

public interface MeetingRepository extends CrudRepository<Meeting, Integer>{
List<Meeting> findBySchedulerName(String schedulerName);
List<Meeting> findByschedulerNameAndMeetingDate(String schedulerName, LocalDate meetingDate);
List<Meeting> findByTeamNameAndMeetingDate(String teamName,LocalDate meetingDate);
}
