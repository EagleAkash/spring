package com.infy.meetingscheduler.validator;

import java.time.DayOfWeek;
import java.time.LocalDate;

import com.infy.meetingscheduler.dto.MeetingDTO;
import com.infy.meetingscheduler.exception.MeetingSchedulerException;

public class MeetingValidator {
	public MeetingValidator() {
	
		// TODO Auto-generated constructor stub
	}

	public static void validateMeeting(MeetingDTO meetingDTO) throws MeetingSchedulerException
	{
		if(isValidTeamName(meetingDTO.getTeamName())==false)
		{
			throw new MeetingSchedulerException("MeetingValidator.INVALID_TEAM_NAME");
		}
		if(isValidMeetingDate(meetingDTO.getMeetingDate())== false)
			
		{
			throw new MeetingSchedulerException("MeetingValidator.INVALID_MEETING_DATE");
		}
	}
	
	public static  Boolean isValidTeamName(String teamName)  throws MeetingSchedulerException
	{
		String regex="(ETAMYSJAVA|ETAMYSBI|ETAMYSMS|ETAMYSUI|ETAMYSAI)";
		if(teamName.matches(regex))
		{
			return true;
		}
		return false;
		
	}
	public  static Boolean isValidMeetingDate(LocalDate meetingDate)  throws MeetingSchedulerException
	{
		if(meetingDate.getDayOfWeek().equals(DayOfWeek.SATURDAY)|| meetingDate.getDayOfWeek().equals(DayOfWeek.SUNDAY))
		{
			return false;
		}
		return true;
		
	}

	
}
