package com.infy.meetingscheduler.api;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.meetingscheduler.dto.MeetingDTO;
import com.infy.meetingscheduler.exception.MeetingSchedulerException;
import com.infy.meetingscheduler.service.MeetingService;
@RestController
@RequestMapping(value="api")
@Validated
public class MeetingAPI {
	@Autowired
	private MeetingService meetingService;
	 @GetMapping(value = "meetings/{schedulerName}")
	public ResponseEntity<List<MeetingDTO>> getAllMeetingOfScheduler(@PathVariable @Valid 	@Pattern(regexp = "[A-Za-z]+(\\s[A-Za-z]+)*", message = "{meeting.scheduler.invalid}")
 String schedulerName) throws MeetingSchedulerException
	{
	List<MeetingDTO> meetingDTOs=	 meetingService.getAllMeetingOfScheduler(schedulerName);
		return new ResponseEntity<List<MeetingDTO>>(meetingDTOs,HttpStatus.OK);
		
	}
	@PostMapping(value = "meetings", consumes = "application/json")
	public ResponseEntity<MeetingDTO> scheduleMeeting(@RequestBody MeetingDTO meetingDTO) throws MeetingSchedulerException
	{
	MeetingDTO meetingDTO2=	meetingService.scheduleMeeting(meetingDTO);
		return new ResponseEntity<MeetingDTO>(meetingDTO2,HttpStatus.CREATED);
		
	}
}
