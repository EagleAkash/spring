package com.infy.meetingscheduler.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.meetingscheduler.dto.MeetingDTO;
import com.infy.meetingscheduler.entity.Meeting;
import com.infy.meetingscheduler.exception.MeetingSchedulerException;
import com.infy.meetingscheduler.repository.MeetingRepository;
import com.infy.meetingscheduler.validator.MeetingValidator;
@Service(value = "meetingService")
@Transactional
public class MeetingServiceImpl  implements MeetingService{
	@Autowired
	MeetingRepository meetingRepository;

	@Override
	public List<MeetingDTO> getAllMeetingOfScheduler(String schedulerName) throws MeetingSchedulerException {
		// TODO Auto-generated method stub
	List<Meeting> meetingslist=	meetingRepository.findBySchedulerName(schedulerName);
	if(meetingslist.isEmpty())
	{
		throw new MeetingSchedulerException("MeetingService.NO_MEETINGS_FOUND");
	}
	List<MeetingDTO> meetingdtolist= new ArrayList<>();
	for( Meeting meeting:meetingslist)
	{
	MeetingDTO meetingDTO=	MeetingDTO.prepareDTO(meeting);
	meetingdtolist.add(meetingDTO);
	}
	meetingdtolist.sort((m1,m2)->m1.getMeetingDate().compareTo(m2.getMeetingDate()));
		return meetingdtolist;
	}

	@Override
	public MeetingDTO scheduleMeeting(MeetingDTO meetingDTO)  throws MeetingSchedulerException{
		// TODO Auto-generated method stub
		MeetingValidator.validateMeeting(meetingDTO);
List<Meeting>	meetings=meetingRepository.findByschedulerNameAndMeetingDate(meetingDTO.getSchedulerName(), meetingDTO.getMeetingDate());
		if(!meetings.isEmpty())
		{
			throw new MeetingSchedulerException("MeetingService.MEETING_DATE_UNAVAILABLE");
		}
	List<Meeting> meetingsByTeam=	meetingRepository.findByTeamNameAndMeetingDate(meetingDTO.getTeamName(), meetingDTO.getMeetingDate());
	if(!meetingsByTeam.isEmpty())
	{
		throw new MeetingSchedulerException("MeetingService.TEAM_UNAVAILABLE");
	}
	Meeting meeting= MeetingDTO.prepareEntity(meetingDTO);
      Meeting meet=	meetingRepository.save(meeting);
      meetingDTO.setMeetingId(meet.getMeetingId());
		return meetingDTO;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
