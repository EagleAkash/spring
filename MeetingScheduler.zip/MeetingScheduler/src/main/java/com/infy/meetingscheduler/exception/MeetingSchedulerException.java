package com.infy.meetingscheduler.exception;

public class MeetingSchedulerException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public MeetingSchedulerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
