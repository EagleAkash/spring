package com.infy.moviebooking.repository;

public interface MovieBookingRepository {

}
