package com.infy.moviebooking.validator;

import com.infy.moviebooking.dto.MovieBookingDTO;
import com.infy.moviebooking.exception.MovieBookingException;

public class MovieBookingValidator {

	private MovieBookingValidator()
	{
		
	}
	public static void validate(MovieBookingDTO movieBookingDTO) throws MovieBookingException
	{
		
	}
	public static Boolean isValidPaymentType(String paymentType) throws MovieBookingException
	{
		return null;
		
	}
	public static Boolean isValidCustomerPhoneNo(Long customerPhoneNo) throws MovieBookingException
	{
		return null;
		
	}
}
